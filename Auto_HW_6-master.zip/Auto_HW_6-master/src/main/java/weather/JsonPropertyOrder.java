package weather;

public @interface JsonPropertyOrder {
}
